# Changelog

- 2025-10-23: Initial import and automated extraction from uploaded PDF.
