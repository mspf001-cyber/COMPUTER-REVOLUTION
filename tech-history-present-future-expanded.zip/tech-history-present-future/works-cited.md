# Works Cited

Works cited extracted into docs/Tech_History_Present_and_Future.pdf. See that file for full list.