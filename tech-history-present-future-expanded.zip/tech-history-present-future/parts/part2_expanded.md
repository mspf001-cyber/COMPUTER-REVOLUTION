# Part 2 — Modern Technopoly: Ecosystem Analysis

## Summary
Analysis of industry structure, major companies, supply chains, research institutions, and market forces that define today's technology ecosystem. Includes geopolitics, manufacturing constraints, and talent flows.

## 1. The Titans and Their Roles
- **Hyperscalers**: Amazon (AWS), Microsoft (Azure), Google (GCP) provide cloud infrastructure dominating compute and services.
- **Semiconductor leaders**: TSMC for foundry services; Intel, Samsung in fabrication and design. fileciteturn2file0
- **Hardware accelerators**: Nvidia leads GPUs for training and inference. fileciteturn2file12

## 2. Corporate Profiles and Strategic Assets
- Data centers, proprietary datasets, talent pools, and specialized silicon are the main moats.
- Software ecosystems and developer platforms create lock-in.

## 3. Supply Chain and Manufacturing Constraints
- Advanced node fabrication concentration presents geopolitical risk.
- Raw-material supply, packaging, and specialized equipment (EUV lithography) are critical.

## 4. Research and Open Science
- Academia and industry labs (e.g., major university groups, corporate research labs) drive algorithmic advances.
- Open-source frameworks accelerated adoption and replication.

## 5. Regulation, Standards, and Policy
- Data sovereignty, AI policy, antitrust, and export controls shape strategy.
- National investments in chips and AI reshuffle competitive balance.

## 6. Market Indicators (as cited in the document)
- The source document includes a Q4 2025 snapshot of market capitalization and a list of major corporate events. See `works-cited.md` and `docs/` for direct references. fileciteturn2file13

## Suggested subheadings for expansion
- Hyperscaler economics
- Semiconductor supply chain mapping
- Talent and migration patterns
- Open-source and research ecosystems
- Regulation and international strategy
