# Image attribution

Place image files in this folder and add source URLs and license info here.

Examples:
- ada_lovelace.jpg — source: Wikimedia Commons (public domain). 
- eniac.jpg — source: University of Pennsylvania archives / public domain.
- iphone_2007.jpg — source: Apple press assets.
- nvidia_h100.jpg — source: Nvidia press kit.
