# Tech History, Present, and Future

A structured, elaborated repository built from the original research PDF.  
Source PDF: `docs/Tech_History_Present_and_Future.pdf`. Citation: fileciteturn2file0

## Repo structure
- `parts/part1_expanded.md` — expanded, edited chapter (history).
- `parts/part2_expanded.md` — expanded, edited chapter (ecosystem analysis).
- `parts/part3_expanded.md` — expanded, edited chapter (future revolutions).

## Repo structure
- `README.md` — this file.
- `docs/Tech_History_Present_and_Future.pdf` — original source PDF. fileciteturn2file0
- `parts/part1.md` — Chronological history and foundational concepts.
- `parts/part2.md` — Ecosystem analysis and company/person profiles.
- `parts/part3.md` — Ten speculative future revolutions.
- `timeline.md` — extracted key dates and events.
- `works-cited.md` — extracted works cited from the PDF.
- `assets/images/` — placeholder images and attribution.

## Quick summary
The document traces computing from Babbage and Lovelace through Turing, ENIAC, transistors, integrated circuits, personal computing, the Web, mobile/cloud, and the AI era. It then analyzes the modern "technopoly" and profiles major companies and individuals. Finally it outlines 10 speculative revolutions including fusion, AGI, BCI, longevity, nanotech, quantum, energy storage, precision medicine, DAOs, and space resource extraction. fileciteturn2file1

## How the parts were created
Text was programmatically extracted from the uploaded PDF and split into three main parts. The original PDF is retained in `docs/` for verification and full references. fileciteturn2file0

## Suggested images and attribution
Place images in `assets/images/`:
- `ada_lovelace.jpg` — Ada Lovelace portrait (Wikimedia Commons). See original PDF works-cited for source. fileciteturn2file6
- `eniac.jpg` — ENIAC machine photo. fileciteturn2file12
- `iphone_2007.jpg` — iPhone (2007) product image. fileciteturn2file13
- `nvidia_h100.jpg` — Nvidia GPU / H100 image. fileciteturn2file19

Include `ATTRIBUTION.md` inside `assets/images/` with links to original image sources.

## How to publish
```bash
git init
git add .
git commit -m "Elaborated import of Tech History, Present, and Future"
# create GH repo and push using GH CLI or web UI
```

## Notes & provenance
This repo was generated from the uploaded PDF. All extracted text and citations reference the original file. Use `docs/Tech_History_Present_and_Future.pdf` as the authoritative source. fileciteturn2file0


## Major URLs extracted from source
- https://unstop.com/blog/difference-engine-versus-analytical-engine
- https://en.wikipedia.org/wiki/Analytical_engine
- https://www.nist.gov/blogs/taking-measure/ada-lovelace-worlds-first-computer-programmer-who-
- https://www.historyofdatascience.com/ada-lovelace/#:~:text=Most%20notably%2C%20Lovelace
- https://www.britannica.com/biography/George-Boole
- https://www.ebsco.com/research-starters/science/boolean-algebra
- https://plato.stanford.edu/entries/turing-machine/
- https://www.britannica.com/technology/Turing-machine
- https://www.lenovo.com/us/en/glossary/eniac/#:~:text=The%20ENIAC%20revolutionized%20co
- https://en.wikipedia.org/wiki/Transistor
- https://en.wikipedia.org/wiki/Tim_Berners-Lee
- https://en.wikipedia.org/wiki/IBM_mainframe
- https://www.bosch.com/stories/ibm-mainframe-computer-history/
- https://praxent.com/blog/history-of-programming-languages#:~:text=One%20of%20these%20is
- https://praxent.com/blog/history-of-programming-languages
- https://tresbizz.com/blog/evolution-of-integrated-circuits/
- https://en.wikipedia.org/wiki/Invention_of_the_integrated_circuit
- https://www.sjsu.edu/people/robert.chun/courses/CS247/s4/M.pdf
- https://en.wikipedia.org/wiki/Microprocessor_chronology
- https://www.computerhistory.org/revolution/personal-computers/17/300
- https://en.wikipedia.org/wiki/Apple_Inc.
- https://www.ebsco.com/research-starters/computer-science/apple-ii-becomes-first-successful-pr
- https://en.wikipedia.org/wiki/Microsoft
- https://mohai.org/collections-and-research/theme/history-of-microsoft/
- https://news.microsoft.com/announcement/microsoft-is-born/
- https://en.wikipedia.org/wiki/History_of_the_graphical_user_interface
- https://medium.com/@learning3601/in-the-vast-landscape-of-digital-interaction-the-graphical-us
- https://www.cultofmac.com/news/40-moments-that-have-defined-apple-over-40-years
- https://www.lenovo.com/us/en/glossary/arpanet/
- https://www.scienceandmediamuseum.org.uk/objects-and-stories/short-history-internet
- https://home.cern/science/computing/birth-web/short-history-web
- https://en.wikipedia.org/wiki/Dot-com_bubble
- https://bigmedium.com/ideas/how-iphone-changed-computing.html
- https://bigmedium.com/ideas/how-iphone-changed-computing.html#:~:text=The%20iPhone%20
- https://neal-davis.medium.com/the-history-of-aws-and-the-evolution-of-computing-0a64cee5bc1
- https://aws.amazon.com/about-aws/
- https://www.fkcreative.co.uk/fk-blog/the-rise-and-fall-of-facebook-a-social-media-giants-journey
- https://www.limely.co.uk/blog/20-years-of-facebook-the-evolution-of-a-social-media-giant
- https://www.frederick.ai/blog/mark-zuckerberg-meta-facebook
- https://bernardmarr.com/what-is-big-data/
- https://www.pinecone.io/learn/series/image-search/imagenet/
- https://medium.com/@fahey_james/the-story-of-alexnet-a-historical-milestone-in-deep-learning-
- https://huggingface.co/learn/llm-course/chapter1/4
- https://capital.com/en-int/markets/shares/largest-companies-by-market-cap
- https://www.investing.com/academy/stock-picks/largest-market-cap-companies/
- https://companiesmarketcap.com/
- https://www.alpha-sense.com/largest-companies-by-market-cap/
- https://www.investopedia.com/biggest-companies-in-the-world-by-market-cap-5212784
- https://www.ig.com/en/trading-strategies/best-large-cap-stocks-to-watch-in-2025-250115
- https://en.wikipedia.org/wiki/Nvidia

_Updated: 2025-10-23 UTC_
